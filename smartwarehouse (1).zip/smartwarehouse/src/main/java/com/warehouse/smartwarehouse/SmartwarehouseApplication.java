package com.warehouse.smartwarehouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartwarehouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartwarehouseApplication.class, args);
	}

}
